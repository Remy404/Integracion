from flask import Flask, request, jsonify
import hashlib
import base64

app = Flask(__name__)

@app.route('/desencripta', methods=['POST'])
def desencriptaImagen():
    # Obtiene los datos de la solicitud
    data = request.json

    # Extrae la imagen encriptada y la clave de la solicitud
    imagen_encriptada = base64.b64decode(data['message'])


    # Desencripta la imagen
    imagen_desencriptada_base64 = base64.b64encode(imagen_encriptada).decode('utf-8')


    # Devielve la imagen desencriptada como respuesta
    return imagen_desencriptada_base64, 200, {'Content-Type': 'image/jpg'}


if __name__ == '__main__':
    app.run(debug=True, port=5001)
