from flask import Flask, request, jsonify
import hashlib
import random
import base64
import requests
app = Flask(__name__)

url = 'http://localhost:5001/desencripta'

@app.route('/sube', methods=['GET'])
def subeImagen():
    with open('gato.jpg', 'rb') as f:
        archivo = f.read()

    key = str(random.randint(100000, 999999))
    

    # Convierte la imagen a base64
    imagen_base64 = base64.b64encode(archivo).decode()

    # Crea un diccionario con los datos de la imagen en formato JSON
    imagen_json = {
        'message': imagen_base64,
        'key': key
    }

     # Envia la imagen encriptada al servidor para desencriptar
    response = requests.post('http://localhost:5001/desencripta', json=imagen_json)

    if response.status_code == 200:
        # Guarda la imagen desencriptada
        with open('imagen_desencriptada.png', 'wb') as f:
            f.write(response.content)
        return 'Imagen desencriptada con éxito.'
    else:
        return 'Error : {}'.format(response.text), 500


if __name__ == '__main__':
    app.run(debug=True, port=5000)
